const gameBoard = document.getElementById("gameBoard") as HTMLDivElement;
const startButton = document.getElementById("startButton") as HTMLButtonElement;
const message = document.getElementById("message") as HTMLParagraphElement;
const scoreDisplay = document.getElementById("scoreDisplay") as HTMLParagraphElement; 

let pattern: Set<number> = new Set(); 
let clickedButtons: Set<number> = new Set(); 
let level: number = 1;
let buttonCount: number = 4;
let gameOver: boolean = false;
let score: number = 0; 


function createButtons(): void {
    gameBoard.innerHTML = ""; 
    gameBoard.style.gridTemplateColumns = `repeat(${Math.ceil(Math.sqrt(buttonCount))}, 1fr)`;

    for (let i = 0; i < buttonCount; i++) {
        const button = document.createElement("button");
        button.className = "square w-24 h-24 bg-gray-600 rounded transition-colors";
        button.dataset.index = i.toString();
        button.addEventListener("click", () => handleUserClick(i, button));
        gameBoard.appendChild(button);
    }
}


function generatePattern(): void {
    pattern.clear();
    while (pattern.size < level) {
        pattern.add(Math.floor(Math.random() * buttonCount));
    }
}


function showPattern(): void {
    clickedButtons.clear();
    gameOver = false;
    message.textContent = `Bosqich: ${level}`;
    message.className = "text-white mt-2";

    const squares = document.querySelectorAll<HTMLButtonElement>(".square");

 
    squares.forEach((btn, index) => {
        if (pattern.has(index)) {
            btn.classList.add("opacity-50");
        }
    });

   
    setTimeout(() => {
        squares.forEach((btn) => btn.classList.remove("opacity-50"));
    }, 1000);
}

function startGame(): void {
    buttonCount = 4;
    level = 1;
    score = 0; 
    scoreDisplay.textContent = "";
    createButtons();
    generatePattern();
    showPattern();
}


function handleUserClick(index: number, button: HTMLButtonElement): void {
    if (gameOver || clickedButtons.has(index)) return; 

    clickedButtons.add(index);

    if (pattern.has(index)) {
        button.classList.replace("bg-gray-600", "bg-white"); 
        score += 10; // 🎯 10 ball qo‘shish
    } else {
        button.classList.replace("bg-gray-600", "bg-red-600"); 
        message.textContent = `Xato! Yakuniy bosqich: ${level}`;
        message.classList.add("text-red-500");
        scoreDisplay.textContent = `Sizning natijangiz: ${score} ball`;
        scoreDisplay.className = "text-white mt-2";
        gameOver = true; // ❌ O‘yin tugadi
        return;
    }

   
    if (clickedButtons.size === pattern.size) {
        level++;
        if (level % 2 === 0) buttonCount += 2; 
        setTimeout(() => {
            createButtons();
            generatePattern();
            showPattern();
        }, 1000);
    }
}


startButton.addEventListener("click", startGame);
